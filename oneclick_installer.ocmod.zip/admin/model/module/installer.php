<?php
namespace Opencart\Admin\Model\Extension\OneclickInstaller\Module;

/**
 * OneClick Extension Manager - Installer Model v2
 *
 * Adds zip inspection to detect extension type(s) from controller subfolders,
 * detect pure-ocmod packages, and handle multi-type bundles.
 *
 * OC4 PDO note: escape() stores values in $this->data[] as named params.
 * Every escape() must be consumed by the immediately following query().
 *
 * Copyright (c) Map's Edge Creative — https://theroadlessordinary.com
 */
class Installer extends \Opencart\System\Engine\Model {

    /**
     * OC4 recognised extension types (controller subfolder names).
     */
    const KNOWN_TYPES = [
        'analytics', 'captcha', 'currency', 'feed', 'fraud',
        'language', 'module', 'payment', 'report', 'shipping',
        'theme', 'total',
    ];

    private string $tmp_dir              = '';
    private array  $copied_files         = [];
    private ?int   $extension_install_id = null;

    // =========================================================================
    // PUBLIC: Zip Inspection
    // =========================================================================

    /**
     * Inspect a zip file without extracting it to the live filesystem.
     *
     * Returns:
     * [
     *   'valid'      => bool,
     *   'error'      => string|null,
     *   'types'      => string[],        // e.g. ['shipping','payment'] or []
     *   'has_ocmod'  => bool,
     *   'is_pure_ocmod' => bool,         // true when no controller folders found
     *   'manifest'   => array,           // parsed install.json or []
     * ]
     */
    public function inspectZip(string $zip_path): array {
        $result = [
            'valid'         => false,
            'error'         => null,
            'types'         => [],
            'has_ocmod'     => false,
            'is_pure_ocmod' => false,
            'manifest'      => [],
        ];

        $zip = new \ZipArchive();
        if ($zip->open($zip_path) !== true) {
            $result['error'] = 'Could not open zip archive.';
            return $result;
        }

        $types     = [];
        $has_ocmod = false;
        $manifest  = [];

        for ($i = 0; $i < $zip->numFiles; $i++) {
            $entry = $zip->getNameIndex($i);
            if ($entry === false) continue;

            // Normalise path separators
            $entry = str_replace('\\', '/', $entry);

            // install.json at any depth (we want the root one)
            if ($entry === 'install.json' || substr($entry, -13) === '/install.json') {
                $raw = $zip->getFromIndex($i);
                if ($raw !== false) {
                    $decoded = json_decode($raw, true);
                    if (is_array($decoded)) {
                        $manifest = $decoded;
                    }
                }
            }

            // Detect controller folder → type
            // Pattern: (anything/)admin/controller/{type}/{name}.php
            if (preg_match('#(?:^|/)admin/controller/([^/]+)/[^/]+\.php$#i', $entry, $m)) {
                $type = strtolower($m[1]);
                if (in_array($type, self::KNOWN_TYPES, true) && !in_array($type, $types, true)) {
                    $types[] = $type;
                }
            }

            // Detect ocmod XML
            // Matches: install.xml  OR  *.ocmod.xml  at any depth
            if (preg_match('#(?:^|/)(install\.xml|[^/]+\.ocmod\.xml)$#i', $entry)) {
                $has_ocmod = true;
            }
        }

        $zip->close();

        if (empty($manifest)) {
            $result['error'] = 'install.json not found or invalid.';
            return $result;
        }

        $result['valid']         = true;
        $result['types']         = $types;
        $result['has_ocmod']     = $has_ocmod;
        $result['is_pure_ocmod'] = empty($types) && $has_ocmod;
        $result['manifest']      = $manifest;

        return $result;
    }

    // =========================================================================
    // PUBLIC: Full install
    // =========================================================================

    public function fullInstall(array $file): array {
        $steps          = [];
        $rollback_steps = [];
        $extension_name = '';

        $this->tmp_dir              = '';
        $this->copied_files         = [];
        $this->extension_install_id = null;

        // 1. Validate + inspect
        $step = $this->makeStep('validate', 'Validating package');
        try {
            [$manifest, $inspection] = $this->validateAndInspect($file);
            $extension_name = $manifest['name'] ?? $this->filenameToCode($file['name']);
            $type_label     = $this->describeTypes($inspection);
            $steps[]        = $this->passStep($step, 'Package valid — ' . $extension_name . ' v' . ($manifest['version'] ?? '?') . ' [' . $type_label . ']');
            $rollback_steps[] = 'validate';
        } catch (\Exception $e) {
            $steps[] = $this->failStep($step, $e->getMessage());
            return $this->buildResult(false, $steps, $extension_name, $e->getMessage());
        }

        // 1b. Uninstall existing version if present
        $ext_code = $this->filenameToCode($file['name']);
        $existing = $this->db->query("SELECT extension_install_id FROM `" . DB_PREFIX . "extension_install` WHERE `code` = '" . $this->db->escape($ext_code) . "'");
        if ($existing->num_rows) {
            $existing_id = (int)$existing->row['extension_install_id'];
            $step        = $this->makeStep('uninstall_existing', 'Removing existing version');
            $uninstall   = $this->fullUninstall($existing_id);
            if ($uninstall['success']) {
                $steps[] = $this->passStep($step, 'Existing version removed');
                foreach ($uninstall['steps'] as &$s) { $s['label'] = '  ↳ ' . $s['label']; }
                unset($s);
                $steps = array_merge($steps, $uninstall['steps']);
            } else {
                $steps[] = $this->failStep($step, 'Could not remove existing version: ' . ($uninstall['error'] ?? 'unknown error'));
                $steps   = array_merge($steps, $uninstall['steps']);
                return $this->buildResult(false, $steps, $extension_name, 'Uninstall of existing version failed — aborting update.');
            }
        }

        // 2. Extract
        $step = $this->makeStep('extract', 'Extracting files');
        try {
            $this->extract($file['tmp_name']);
            $steps[]          = $this->passStep($step, 'Extracted to temporary directory');
            $rollback_steps[] = 'extract';
        } catch (\Exception $e) {
            $steps[] = $this->failStep($step, $e->getMessage());
            $this->rollback($rollback_steps, $steps);
            return $this->buildResult(false, $steps, $extension_name, $e->getMessage());
        }

        // 3. Copy files
        $step = $this->makeStep('copy_files', 'Copying files');
        try {
            $count            = $this->copyFiles($file['name']);
            $steps[]          = $this->passStep($step, 'Copied ' . $count . ' file' . ($count !== 1 ? 's' : ''));
            $rollback_steps[] = 'copy_files';
        } catch (\Exception $e) {
            $steps[] = $this->failStep($step, $e->getMessage());
            $this->rollback($rollback_steps, $steps);
            return $this->buildResult(false, $steps, $extension_name, $e->getMessage());
        }

        // 4. DB register
        $step = $this->makeStep('db_register', 'Registering in database');
        try {
            $this->dbRegister($file['name'], $manifest, $inspection);
            $steps[]          = $this->passStep($step, 'Registered (ID ' . $this->extension_install_id . ')');
            $rollback_steps[] = 'db_register';
        } catch (\Exception $e) {
            $steps[] = $this->failStep($step, $e->getMessage());
            $this->rollback($rollback_steps, $steps);
            return $this->buildResult(false, $steps, $extension_name, $e->getMessage());
        }

        // 5. Run install controller (non-fatal)
        $step = $this->makeStep('run_install', 'Running extension install routine');
        try {
            $ext_code = $this->filenameToCode($file['name']);
            $ran      = $this->runInstallController($ext_code, $manifest, $inspection);
            $steps[]  = $this->passStep($step, $ran ? 'Install routine completed' : 'No install routine — skipped');
            $rollback_steps[] = 'run_install';
        } catch (\Exception $e) {
            $steps[] = $this->warnStep($step, 'Install routine skipped: ' . $e->getMessage());
        }

        // 6. Refresh modifications (non-fatal)
        $step = $this->makeStep('refresh_mods', 'Refreshing modification cache');
        try {
            $this->refreshModifications();
            $steps[] = $this->passStep($step, 'Modification cache rebuilt');
        } catch (\Exception $e) {
            $steps[] = $this->warnStep($step, 'Cache refresh skipped: ' . $e->getMessage());
        }

        $this->cleanTmp();
        return $this->buildResult(true, $steps, $extension_name);
    }

    // =========================================================================
    // PUBLIC: Full uninstall
    // =========================================================================

    public function fullUninstall(int $id): array {
        $steps  = [];
        $record = $this->getInstallRecord($id);

        if (!$record) {
            return $this->buildResult(false, $steps, '', 'Extension record not found.');
        }

        $ext_code = $record['code'];

        $step = $this->makeStep('disable', 'Disabling extension');
        try {
            $this->db->query("UPDATE `" . DB_PREFIX . "extension_install` SET `status` = 0 WHERE `extension_install_id` = " . (int)$id);
            $steps[] = $this->passStep($step, 'Extension disabled');
        } catch (\Exception $e) {
            $steps[] = $this->warnStep($step, 'Could not disable: ' . $e->getMessage());
        }

        $step = $this->makeStep('remove_files', 'Removing files');
        try {
            $count   = $this->removeExtensionDir($ext_code);
            $steps[] = $this->passStep($step, 'Removed ' . $count . ' file' . ($count !== 1 ? 's' : ''));
        } catch (\Exception $e) {
            $steps[] = $this->failStep($step, $e->getMessage());
            return $this->buildResult(false, $steps, $ext_code, $e->getMessage());
        }

        $step = $this->makeStep('db_remove', 'Removing database record');
        try {
            $this->dbRemove($id, $ext_code);
            $steps[] = $this->passStep($step, 'Database record removed');
        } catch (\Exception $e) {
            $steps[] = $this->failStep($step, $e->getMessage());
            return $this->buildResult(false, $steps, $ext_code, $e->getMessage());
        }

        $step = $this->makeStep('refresh_mods', 'Refreshing modification cache');
        try {
            $this->refreshModifications();
            $steps[] = $this->passStep($step, 'Modification cache rebuilt');
        } catch (\Exception $e) {
            $steps[] = $this->warnStep($step, 'Cache refresh skipped: ' . $e->getMessage());
        }

        return $this->buildResult(true, $steps, $ext_code);
    }

    // =========================================================================
    // PUBLIC: Enable / Disable / List
    // =========================================================================

    public function enableExtension(int $id): void {
        $this->db->query("UPDATE `" . DB_PREFIX . "extension_install` SET `status` = 1 WHERE `extension_install_id` = " . (int)$id);
    }

    public function disableExtension(int $id): void {
        $this->db->query("UPDATE `" . DB_PREFIX . "extension_install` SET `status` = 0 WHERE `extension_install_id` = " . (int)$id);
    }

    /**
     * Returns extensions grouped by tab.
     *
     * Structure:
     * [
     *   'tabs' => [
     *     'module'   => [ ...extensions... ],
     *     'shipping' => [ ...extensions... ],
     *     'mods'     => [ ...extensions... ],
     *     ...
     *   ],
     *   'tab_order' => ['module','shipping','mods'],  // alphabetical, mods last
     * ]
     *
     * Within each tab: active rows first (alphabetical), then inactive rows
     * (alphabetical), each group sorted by name.
     */
    public function getInstalledExtensions(): array {
        try { $this->db->query("SELECT 1"); } catch (\Throwable $e) {}

        $query = $this->db->query("
            SELECT
                ei.extension_install_id,
                ei.code,
                ei.name,
                ei.description,
                ei.version,
                ei.author,
                ei.link,
                ei.status,
                ei.date_added,
                e.type
            FROM `" . DB_PREFIX . "extension_install` ei
            LEFT JOIN `" . DB_PREFIX . "extension` e ON e.code = ei.code
            ORDER BY ei.name ASC
        ");

        if (!$query->num_rows) {
            return ['tabs' => [], 'tab_order' => []];
        }

        $tabs = [];

        foreach ($query->rows as $row) {
            $code   = $row['code'] ?? '';
            $type   = strtolower(trim($row['type'] ?? ''));
            $status = (bool)(int)$row['status'];

            // Determine which tab(s) this extension belongs to.
            // If we have a type and it's a known type, use it.
            // If type is empty or unrecognised, fall back to detecting
            // from the installed filesystem path.
            $tab_keys = [];

            if ($type && in_array($type, self::KNOWN_TYPES, true)) {
                $tab_keys[] = $type;
            } else {
                // Inspect installed files to determine type(s)
                $detected = $this->detectTypesFromFilesystem($code);
                if (!empty($detected)) {
                    $tab_keys = $detected;
                } else {
                    // Check for ocmod registration
                    $mod_q = $this->db->query("SELECT modification_id FROM `" . DB_PREFIX . "modification` WHERE `code` = '" . $this->db->escape($code) . "'");
                    $tab_keys[] = $mod_q->num_rows ? 'mods' : 'module';
                }
            }

            // Also add 'mods' tab if this extension has an ocmod record
            $mod_q = $this->db->query("SELECT modification_id FROM `" . DB_PREFIX . "modification` WHERE `code` = '" . $this->db->escape($code) . "'");
            if ($mod_q->num_rows && !in_array('mods', $tab_keys, true)) {
                // It has both a type AND ocmod — don't add mods as a separate tab entry;
                // the cross-type note in the UI handles it.
                // But if it's pure ocmod (no other types), use mods tab.
                if (count($tab_keys) === 1 && $tab_keys[0] === 'module') {
                    // Could still be a module+ocmod. Keep module tab; UI shows note.
                }
            }

            $ext_row = [
                'extension_install_id' => (int)$row['extension_install_id'],
                'code'                 => $code,
                'name'                 => $row['name']        ?: $code,
                'description'          => $row['description'] ?: '',
                'version'              => $row['version']     ?: '—',
                'author'               => $row['author']      ?: '—',
                'link'                 => $row['link']        ?: '',
                'type'                 => $type               ?: implode('+', $tab_keys),
                'all_types'            => $tab_keys,
                'edit_type'            => !empty($tab_keys) && $tab_keys[0] !== 'mods' ? $tab_keys[0] : (!empty($type) && $type !== 'mods' ? $type : ''),
                'has_ocmod'            => (bool)$mod_q->num_rows,
                'status'               => $status,
                'date_added'           => $row['date_added'],
            ];

            foreach ($tab_keys as $tk) {
                if (!isset($tabs[$tk])) {
                    $tabs[$tk] = ['active' => [], 'inactive' => []];
                }
                if ($status) {
                    $tabs[$tk]['active'][] = $ext_row;
                } else {
                    $tabs[$tk]['inactive'][] = $ext_row;
                }
            }
        }

        // Sort within each tab: active alphabetical, then inactive alphabetical
        foreach ($tabs as $tk => &$groups) {
            usort($groups['active'],   fn($a, $b) => strcasecmp($a['name'], $b['name']));
            usort($groups['inactive'], fn($a, $b) => strcasecmp($a['name'], $b['name']));
        }
        unset($groups);

        // Build tab order: known types alphabetically, mods last
        $type_tabs = array_filter(array_keys($tabs), fn($k) => $k !== 'mods');
        sort($type_tabs);
        $tab_order = $type_tabs;
        if (isset($tabs['mods'])) {
            $tab_order[] = 'mods';
        }

        return ['tabs' => $tabs, 'tab_order' => $tab_order];
    }

    // =========================================================================
    // PRIVATE: Validation + inspection
    // =========================================================================

    private function validateAndInspect(array $file): array {
        if ($file['error'] !== UPLOAD_ERR_OK) {
            throw new \Exception('Upload error code: ' . $file['error']);
        }
        $name = basename($file['name']);
        if (strlen($name) < 3 || strlen($name) > 128) {
            throw new \Exception('Filename must be between 3 and 128 characters.');
        }
        if (strtolower(substr($name, -10)) !== '.ocmod.zip') {
            throw new \Exception('File must have .ocmod.zip extension.');
        }

        $inspection = $this->inspectZip($file['tmp_name']);
        if (!$inspection['valid']) {
            throw new \Exception($inspection['error'] ?? 'Invalid package.');
        }

        return [$inspection['manifest'], $inspection];
    }

    private function describeTypes(array $inspection): string {
        if ($inspection['is_pure_ocmod']) {
            return 'Mod';
        }
        $parts = array_map('ucfirst', $inspection['types']);
        if ($inspection['has_ocmod']) {
            $parts[] = '+Mod';
        }
        return implode(' + ', $parts) ?: 'Unknown';
    }

    // =========================================================================
    // PRIVATE: Install steps
    // =========================================================================

    private function extract(string $tmp_path): void {
        $this->tmp_dir = sys_get_temp_dir() . '/oneclick_' . md5(uniqid('', true));
        if (!mkdir($this->tmp_dir, 0755, true)) {
            throw new \Exception('Could not create temporary directory.');
        }
        $zip = new \ZipArchive();
        if ($zip->open($tmp_path) !== true) {
            throw new \Exception('Could not open zip for extraction.');
        }
        $zip->extractTo($this->tmp_dir);
        $zip->close();
    }

    private function copyFiles(string $filename): int {
        $ext_code  = $this->filenameToCode($filename);
        $dest_base = DIR_OPENCART . 'extension/' . $ext_code . '/';
        $count     = 0;
        $files     = $this->listFilesRecursive($this->tmp_dir);
        foreach ($files as $source) {
            $relative = substr($source, strlen($this->tmp_dir) + 1);
            if ($relative === 'install.json') {
                continue;
            }
            $dest = $dest_base . $relative;
            $dir  = dirname($dest);
            if (!is_dir($dir)) {
                mkdir($dir, 0755, true);
            }
            $existed = file_exists($dest);
            if (!copy($source, $dest)) {
                throw new \Exception('Could not copy: ' . $relative);
            }
            if (!$existed) {
                $this->copied_files[] = $dest;
            }
            $count++;
        }
        return $count;
    }

    private function dbRegister(string $filename, array $manifest, array $inspection): void {
        $ext_code = $this->filenameToCode($filename);

        // Clean up any prior install record
        $q = $this->db->query("SELECT extension_install_id FROM `" . DB_PREFIX . "extension_install` WHERE `code` = '" . $this->db->escape($ext_code) . "'");
        if ($q->num_rows) {
            $old_id = (int)$q->row['extension_install_id'];
            $this->db->query("DELETE FROM `" . DB_PREFIX . "extension_path` WHERE `extension_install_id` = " . $old_id);
            $this->db->query("DELETE FROM `" . DB_PREFIX . "extension_install` WHERE `extension_install_id` = " . $old_id);
        }

        $this->db->query("INSERT INTO `" . DB_PREFIX . "extension_install` SET
            `code`        = '" . $this->db->escape($ext_code) . "',
            `name`        = '" . $this->db->escape($manifest['name'] ?? $ext_code) . "',
            `description` = '" . $this->db->escape($manifest['description'] ?? '') . "',
            `version`     = '" . $this->db->escape($manifest['version'] ?? '') . "',
            `author`      = '" . $this->db->escape($manifest['author'] ?? '') . "',
            `link`        = '" . $this->db->escape($manifest['link'] ?? '') . "',
            `status`      = 1,
            `date_added`  = NOW()");

        $this->extension_install_id = (int)$this->db->getLastId();

        // Register file paths
        $ext_dir = DIR_OPENCART . 'extension/' . $ext_code . '/';
        $this->registerExtensionPaths($this->extension_install_id, $ext_dir);

        // Register each detected type in oc_extension
        $types = $inspection['types'];
        if (empty($types) && !empty($manifest['type'])) {
            $types = [$manifest['type']];
        }
        foreach ($types as $type) {
            $code_for_type = $manifest['code'] ?? $ext_code;
            $q = $this->db->query("SELECT extension_id FROM `" . DB_PREFIX . "extension` WHERE `type` = '" . $this->db->escape($type) . "' AND `code` = '" . $this->db->escape($code_for_type) . "'");
            if (!$q->num_rows) {
                $this->db->query("INSERT INTO `" . DB_PREFIX . "extension` SET `type` = '" . $this->db->escape($type) . "', `code` = '" . $this->db->escape($code_for_type) . "'");
            }
        }

        // Register any ocmod XML files
        $xml_files = glob(DIR_OPENCART . 'extension/' . $ext_code . '/ocmod/*.ocmod.xml') ?: [];
        // Also check root-level install.xml
        $install_xml = DIR_OPENCART . 'extension/' . $ext_code . '/install.xml';
        if (file_exists($install_xml)) {
            $xml_files[] = $install_xml;
        }
        // Also check root-level ocmod.xml (flat zip layout — no /ocmod/ subfolder)
        $root_ocmod = DIR_OPENCART . 'extension/' . $ext_code . '/ocmod.xml';
        if (file_exists($root_ocmod) && !in_array($root_ocmod, $xml_files, true)) {
            $xml_files[] = $root_ocmod;
        }
        foreach ($xml_files as $xml_file) {
            $xml = file_get_contents($xml_file);
            if (!$xml) continue;
            $dom = new \DOMDocument('1.0', 'UTF-8');
            $dom->preserveWhiteSpace = false;
            $xml_name        = $manifest['name'] ?? $ext_code;
            $xml_description = $manifest['description'] ?? '';
            $xml_author      = $manifest['author']  ?? '';
            $xml_version     = $manifest['version'] ?? '';
            $xml_link        = $manifest['link']    ?? '';
            try {
                $dom->loadXml($xml);
                $get = function(string $tag) use ($dom): string {
                    $el = $dom->getElementsByTagName($tag)->item(0);
                    return $el ? trim($el->textContent) : '';
                };
                if ($get('name'))        { $xml_name        = $get('name'); }
                if ($get('description')) { $xml_description = $get('description'); }
                if ($get('author'))      { $xml_author      = $get('author'); }
                if ($get('version'))     { $xml_version     = $get('version'); }
                if ($get('link'))        { $xml_link        = $get('link'); }
            } catch (\Throwable $e) {}

            $this->db->query("DELETE FROM `" . DB_PREFIX . "modification` WHERE `code` = '" . $this->db->escape($ext_code) . "'");
            $this->db->query("INSERT INTO `" . DB_PREFIX . "modification` SET
                `name`       = '" . $this->db->escape($xml_name) . "',
                `code`       = '" . $this->db->escape($ext_code) . "',
                `author`     = '" . $this->db->escape($xml_author) . "',
                `version`    = '" . $this->db->escape($xml_version) . "',
                `link`       = '" . $this->db->escape($xml_link) . "',
                `xml`        = '" . $this->db->escape($xml) . "',
                `status`     = 1,
                `date_added` = NOW()");
        }
    }

    private function registerExtensionPaths(int $install_id, string $ext_dir): void {
        if (!is_dir($ext_dir)) {
            return;
        }
        $base  = str_replace('\\', '/', DIR_OPENCART . 'extension/');
        $items = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($ext_dir, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::SELF_FIRST
        );
        foreach ($items as $item) {
            $relative = rtrim(substr(str_replace('\\', '/', $item->getPathname()), strlen($base)), '/');
            $this->db->query("INSERT INTO `" . DB_PREFIX . "extension_path` SET
                `extension_install_id` = " . (int)$install_id . ",
                `path` = '" . $this->db->escape($relative) . "'");
        }
    }

    private function runInstallController(string $ext_code, array $manifest, array $inspection): bool {
        $types = $inspection['types'] ?: [$manifest['type'] ?? 'module'];
        $code  = $manifest['code'] ?? $ext_code;
        foreach ($types as $type) {
            $route = 'extension/' . $ext_code . '/' . $type . '/' . $code . '|install';
            try {
                ob_start();
                $this->load->controller($route);
                ob_end_clean();
                return true;
            } catch (\Throwable $e) {
                ob_end_clean();
            }
        }
        return false;
    }

    // =========================================================================
    // PRIVATE: Type detection from filesystem (for already-installed extensions)
    // =========================================================================

    private function detectTypesFromFilesystem(string $ext_code): array {
        $types    = [];
        $base_dir = DIR_OPENCART . 'extension/' . $ext_code . '/admin/controller/';
        if (!is_dir($base_dir)) {
            return $types;
        }
        foreach (scandir($base_dir) ?: [] as $entry) {
            if ($entry === '.' || $entry === '..') continue;
            $type = strtolower($entry);
            if (is_dir($base_dir . $entry) && in_array($type, self::KNOWN_TYPES, true)) {
                $types[] = $type;
            }
        }
        return $types;
    }

    // =========================================================================
    // PRIVATE: Modification refresh
    // =========================================================================

    private function refreshModifications(): void {
        $ocmod_dir = DIR_EXTENSION . 'ocmod/';

        $path  = [$ocmod_dir . '*'];
        $files = [];
        while (count($path) != 0) {
            $next = array_shift($path);
            foreach (glob($next) ?: [] as $file) {
                if (is_dir($file)) { $path[] = $file . '/*'; }
                $files[] = $file;
            }
        }
        rsort($files);
        foreach ($files as $file) {
            if ($file === $ocmod_dir . 'index.html') continue;
            if (is_file($file))    { unlink($file); }
            elseif (is_dir($file)) { @rmdir($file); }
        }

        $xml = [];
        foreach (glob(DIR_SYSTEM . '*.ocmod.xml') ?: [] as $f) {
            $xml[] = file_get_contents($f);
        }
        $this->load->model('setting/modification');
        foreach ($this->model_setting_modification->getModifications() as $mod) {
            if ($mod['status']) { $xml[] = $mod['xml']; }
        }

        $original     = [];
        $modification = [];

        foreach ($xml as $x) {
            if (empty($x)) continue;
            $dom = new \DOMDocument('1.0', 'UTF-8');
            $dom->preserveWhiteSpace = false;
            $dom->loadXml($x);
            $root = $dom->getElementsByTagName('modification')->item(0);
            if (!$root) continue;
            $mod_files = $root->getElementsByTagName('file');
            foreach ($mod_files as $mod_file) {
                $operations = $mod_file->getElementsByTagName('operation');
                $paths = explode('|', str_replace('\\', '/', $mod_file->getAttribute('path')));
                foreach ($paths as $p) {
                    $full = '';
                    if (str_starts_with($p, 'catalog'))   { $full = DIR_CATALOG    . substr($p, 8); }
                    if (str_starts_with($p, 'admin'))     { $full = DIR_APPLICATION . substr($p, 6); }
                    if (str_starts_with($p, 'extension')) { $full = DIR_EXTENSION   . substr($p, 10); }
                    if (str_starts_with($p, 'system'))    { $full = DIR_SYSTEM      . substr($p, 7); }
                    if (!$full) continue;
                    foreach (glob($full, GLOB_BRACE) ?: [] as $filepath) {
                        if (str_starts_with($filepath, DIR_APPLICATION))   { $key = 'admin/'     . substr($filepath, strlen(DIR_APPLICATION)); }
                        elseif (str_starts_with($filepath, DIR_CATALOG))   { $key = 'catalog/'   . substr($filepath, strlen(DIR_CATALOG)); }
                        elseif (str_starts_with($filepath, DIR_EXTENSION)) { $key = 'extension/' . substr($filepath, strlen(DIR_EXTENSION)); }
                        elseif (str_starts_with($filepath, DIR_SYSTEM))    { $key = 'system/'    . substr($filepath, strlen(DIR_SYSTEM)); }
                        else continue;
                        if (!isset($modification[$key])) {
                            $c = preg_replace('~\r\n~', "\n", file_get_contents($filepath));
                            $modification[$key] = $c;
                            $original[$key]     = $c;
                        }
                        $recovery = $modification;
                        foreach ($operations as $op) {
                            $error     = $op->getAttribute('error');
                            $search_el = $op->getElementsByTagName('search')->item(0);
                            $add_el    = $op->getElementsByTagName('add')->item(0);
                            if (!$search_el || !$add_el) continue;
                            $status = false;
                            if ($search_el->getAttribute('regex') != 'true') {
                                $search   = ($search_el->getAttribute('trim') == 'false') ? $search_el->textContent : trim($search_el->textContent);
                                $add      = ($add_el->getAttribute('trim') == 'true') ? trim($add_el->textContent) : $add_el->textContent;
                                $position = $add_el->getAttribute('position') ?: 'replace';
                                $offset   = (int)$add_el->getAttribute('offset');
                                $idx_attr = $search_el->getAttribute('index');
                                $indexes  = $idx_attr !== '' ? explode(',', $idx_attr) : [];
                                $lines    = explode("\n", $modification[$key]);
                                $i = 0;
                                for ($li = 0; $li < count($lines); $li++) {
                                    if (stripos($lines[$li], $search) !== false) {
                                        if (!$indexes || in_array($i, $indexes)) {
                                            $new_lines = explode("\n", $add);
                                            switch ($position) {
                                                case 'before':
                                                    array_splice($lines, $li - $offset, 0, $new_lines);
                                                    $li += count($new_lines);
                                                    break;
                                                case 'after':
                                                    array_splice($lines, ($li + 1) + $offset, 0, $new_lines);
                                                    $li += count($new_lines);
                                                    break;
                                                default:
                                                    if ($offset < 0) {
                                                        array_splice($lines, $li + $offset, abs($offset) + 1, [str_replace($search, $add, $lines[$li])]);
                                                        $li -= $offset;
                                                    } else {
                                                        array_splice($lines, $li, $offset + 1, [str_replace($search, $add, $lines[$li])]);
                                                    }
                                            }
                                            $status = true;
                                        }
                                        $i++;
                                    }
                                }
                                $modification[$key] = implode("\n", $lines);
                            } else {
                                $search  = trim($search_el->textContent);
                                $replace = trim($add_el->textContent);
                                $limit   = (int)$search_el->getAttribute('limit') ?: -1;
                                preg_match($search, $modification[$key], $m);
                                if ($m) { $status = true; }
                                $modification[$key] = preg_replace($search, $replace, $modification[$key], $limit);
                            }
                            if (!$status) {
                                if ($error == 'abort') { $modification = $recovery; break 3; }
                            }
                        }
                    }
                }
            }
        }

        foreach ($modification as $key => $value) {
            if ($original[$key] === $value) continue;
            $dir = dirname($ocmod_dir . $key);
            if (!is_dir($dir)) { @mkdir($dir, 0777, true); }
            file_put_contents($ocmod_dir . $key, $value);
        }

        $this->clearDirectory(DIR_STORAGE . 'cache/template/');
    }

    // =========================================================================
    // PRIVATE: Rollback
    // =========================================================================

    private function rollback(array $completed, array &$steps): void {
        foreach (array_reverse($completed) as $key) {
            switch ($key) {
                case 'copy_files':
                    foreach ($this->copied_files as $f) {
                        if (file_exists($f)) { @unlink($f); }
                    }
                    $steps[] = $this->makeRollbackStep('Rolled back: removed copied files');
                    break;
                case 'db_register':
                    if ($this->extension_install_id) {
                        $this->db->query("DELETE FROM `" . DB_PREFIX . "extension_install` WHERE `extension_install_id` = " . (int)$this->extension_install_id);
                        $this->db->query("DELETE FROM `" . DB_PREFIX . "extension_path` WHERE `extension_install_id` = " . (int)$this->extension_install_id);
                        $steps[] = $this->makeRollbackStep('Rolled back: removed database records');
                    }
                    break;
                case 'extract':
                    $this->cleanTmp();
                    break;
            }
        }
    }

    // =========================================================================
    // PRIVATE: Uninstall helpers
    // =========================================================================

    private function removeExtensionDir(string $ext_code): int {
        $ext_dir = DIR_OPENCART . 'extension/' . $ext_code . '/';
        $count   = 0;
        if (is_dir($ext_dir)) {
            $files = $this->listFilesRecursive($ext_dir);
            foreach ($files as $f) {
                @unlink($f);
                $count++;
            }
            $this->clearDirectory($ext_dir);
            @rmdir($ext_dir);
        }
        return $count;
    }

    private function dbRemove(int $id, string $ext_code): void {
        $this->db->query("DELETE FROM `" . DB_PREFIX . "extension_install` WHERE `extension_install_id` = " . (int)$id);
        $this->db->query("DELETE FROM `" . DB_PREFIX . "extension_path` WHERE `extension_install_id` = " . (int)$id);
        $this->db->query("DELETE FROM `" . DB_PREFIX . "extension` WHERE `code` = '" . $this->db->escape($ext_code) . "'");
        $this->db->query("DELETE FROM `" . DB_PREFIX . "setting` WHERE `store_id` = 0 AND `code` LIKE '" . $this->db->escape($ext_code . '%') . "'");
        $this->db->query("DELETE FROM `" . DB_PREFIX . "modification` WHERE `code` = '" . $this->db->escape($ext_code) . "'");
    }

    // =========================================================================
    // PRIVATE: Utilities
    // =========================================================================

    private function getInstallRecord(int $id): ?array {
        $q = $this->db->query("SELECT * FROM `" . DB_PREFIX . "extension_install` WHERE `extension_install_id` = " . (int)$id);
        return $q->num_rows ? $q->row : null;
    }

    private function filenameToCode(string $filename): string {
        return str_replace(['.ocmod.zip', '-'], ['', '_'], strtolower(basename($filename)));
    }

    private function listFilesRecursive(string $dir): array {
        $result = [];
        $items  = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS));
        foreach ($items as $item) {
            if ($item->isFile()) {
                $result[] = $item->getPathname();
            }
        }
        return $result;
    }

    private function clearDirectory(string $dir): void {
        if (!is_dir($dir)) return;
        $items = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ($items as $item) {
            $item->isDir() ? @rmdir($item->getPathname()) : @unlink($item->getPathname());
        }
    }

    private function cleanTmp(): void {
        if ($this->tmp_dir && is_dir($this->tmp_dir)) {
            $this->clearDirectory($this->tmp_dir);
            @rmdir($this->tmp_dir);
        }
    }

    private function makeStep(string $key, string $label): array {
        return ['key' => $key, 'label' => $label, 'status' => 'pending', 'message' => ''];
    }
    private function passStep(array $s, string $m): array   { return array_merge($s, ['status' => 'pass',     'message' => $m]); }
    private function failStep(array $s, string $m): array   { return array_merge($s, ['status' => 'fail',     'message' => $m]); }
    private function warnStep(array $s, string $m): array   { return array_merge($s, ['status' => 'warn',     'message' => $m]); }
    private function makeRollbackStep(string $m): array     { return ['key' => 'rollback', 'label' => 'Rollback', 'status' => 'rollback', 'message' => $m]; }
    private function buildResult(bool $ok, array $steps, string $name, string $err = ''): array {
        $r = ['success' => $ok, 'steps' => $steps, 'extension_name' => $name];
        if ($err) { $r['error'] = $err; }
        return $r;
    }
}
