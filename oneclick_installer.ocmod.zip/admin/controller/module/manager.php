<?php
namespace Opencart\Admin\Controller\Extension\OneclickInstaller\Module;

/**
 * OneClick Extension Manager - Manager Controller v2
 *
 * Copyright (c) Map's Edge Creative — https://theroadlessordinary.com
 */
class Manager extends \Opencart\System\Engine\Controller {

    public function index(): void {
        $this->load->language('extension/oneclick_installer/module/installer');
        $this->load->model('extension/oneclick_installer/module/installer');

        $this->document->setTitle($this->language->get('heading_title'));

        $data['heading_title']      = $this->language->get('heading_title');
        $data['text_installed']     = $this->language->get('text_installed');
        $data['text_no_extensions'] = $this->language->get('text_no_extensions');
        $data['text_drop_hint']     = $this->language->get('text_drop_hint');
        $data['button_upload']      = $this->language->get('button_upload');
        $data['button_enable']      = $this->language->get('button_enable');
        $data['button_disable']     = $this->language->get('button_disable');
        $data['button_edit']        = $this->language->get('button_edit');
        $data['button_uninstall']   = $this->language->get('button_uninstall');

        $data['upload_url']    = $this->url->link('extension/oneclick_installer/module/manager|upload',    'user_token=' . $this->session->data['user_token']);
        $data['uninstall_url'] = $this->url->link('extension/oneclick_installer/module/manager|uninstall', 'user_token=' . $this->session->data['user_token']);
        $data['enable_url']    = $this->url->link('extension/oneclick_installer/module/manager|enable',    'user_token=' . $this->session->data['user_token']);
        $data['disable_url']   = $this->url->link('extension/oneclick_installer/module/manager|disable',   'user_token=' . $this->session->data['user_token']);
        $data['user_token']    = $this->session->data['user_token'];

        $ext_data               = $this->model_extension_oneclick_installer_module_installer->getInstalledExtensions();
        $data['tabs']           = $ext_data['tabs'];
        $data['tab_order']      = $ext_data['tab_order'];

        $data['breadcrumbs'] = [
            ['text' => $this->language->get('text_home'), 'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])],
            ['text' => $this->language->get('heading_title'), 'href' => $this->url->link('extension/oneclick_installer/module/manager', 'user_token=' . $this->session->data['user_token'])],
        ];

        $data['header']      = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer']      = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/oneclick_installer/module/manager', $data));
    }

    public function upload(): void {
        $this->load->language('extension/oneclick_installer/module/installer');
        $this->load->model('extension/oneclick_installer/module/installer');

        $json = ['steps' => [], 'success' => false, 'extension_name' => ''];

        if (!$this->user->hasPermission('modify', 'extension/oneclick_installer/module/manager')) {
            $json['error'] = $this->language->get('error_permission');
            $this->jsonResponse($json); return;
        }
        if (empty($_FILES['file']['name'])) {
            $json['error'] = $this->language->get('error_no_file');
            $this->jsonResponse($json); return;
        }
        if (strtolower(substr($_FILES['file']['name'], -10)) !== '.ocmod.zip') {
            $json['error'] = $this->language->get('error_filetype');
            $this->jsonResponse($json); return;
        }

        $result = $this->model_extension_oneclick_installer_module_installer->fullInstall($_FILES['file']);

        $json['steps']          = $result['steps'];
        $json['success']        = $result['success'];
        $json['extension_name'] = $result['extension_name'] ?? '';
        if (!$result['success']) {
            $json['error'] = $result['error'] ?? $this->language->get('error_install_failed');
        }

        $json['tab_data'] = $this->fetchTabDataDirect();
        $this->jsonResponse($json);
    }

    public function enable(): void {
        $this->load->language('extension/oneclick_installer/module/installer');
        $this->load->model('extension/oneclick_installer/module/installer');
        $json = [];

        if (!$this->user->hasPermission('modify', 'extension/oneclick_installer/module/manager')) {
            $json['error'] = $this->language->get('error_permission');
            $this->jsonResponse($json); return;
        }
        $id = (int)($this->request->post['extension_install_id'] ?? 0);
        if (!$id) { $json['error'] = $this->language->get('error_invalid_id'); $this->jsonResponse($json); return; }

        $this->model_extension_oneclick_installer_module_installer->enableExtension($id);
        $json['success']  = $this->language->get('text_enabled');
        $json['tab_data'] = $this->fetchTabDataDirect();
        $this->jsonResponse($json);
    }

    public function disable(): void {
        $this->load->language('extension/oneclick_installer/module/installer');
        $this->load->model('extension/oneclick_installer/module/installer');
        $json = [];

        if (!$this->user->hasPermission('modify', 'extension/oneclick_installer/module/manager')) {
            $json['error'] = $this->language->get('error_permission');
            $this->jsonResponse($json); return;
        }
        $id = (int)($this->request->post['extension_install_id'] ?? 0);
        if (!$id) { $json['error'] = $this->language->get('error_invalid_id'); $this->jsonResponse($json); return; }

        $this->model_extension_oneclick_installer_module_installer->disableExtension($id);
        $json['success']  = $this->language->get('text_disabled');
        $json['tab_data'] = $this->fetchTabDataDirect();
        $this->jsonResponse($json);
    }

    public function uninstall(): void {
        $this->load->language('extension/oneclick_installer/module/installer');
        $this->load->model('extension/oneclick_installer/module/installer');
        $json = [];

        if (!$this->user->hasPermission('modify', 'extension/oneclick_installer/module/manager')) {
            $json['error'] = $this->language->get('error_permission');
            $this->jsonResponse($json); return;
        }
        $id = (int)($this->request->post['extension_install_id'] ?? 0);
        if (!$id) { $json['error'] = $this->language->get('error_invalid_id'); $this->jsonResponse($json); return; }

        $result = $this->model_extension_oneclick_installer_module_installer->fullUninstall($id);

        $json['steps']   = $result['steps'];
        $json['success'] = $result['success'];
        if (!$result['success']) {
            $json['error'] = $result['error'] ?? $this->language->get('error_uninstall_failed');
        }

        $json['tab_data'] = $this->fetchTabDataDirect();
        $this->jsonResponse($json);
    }

    // =========================================================================
    // PRIVATE
    // =========================================================================

    private function flushPdoParams(): void {
        try {
            $dbRef = new \ReflectionProperty($this->db, 'adaptor');
            $dbRef->setAccessible(true);
            $adaptor = $dbRef->getValue($this->db);
            $dataRef = new \ReflectionProperty($adaptor, 'data');
            $dataRef->setAccessible(true);
            $dataRef->setValue($adaptor, []);
        } catch (\Throwable $e) {
            for ($i = 0; $i < 10; $i++) {
                try { $this->db->query("SELECT " . ($i + 1)); break; } catch (\Throwable $e2) {}
            }
        }
    }

    private function fetchTabDataDirect(): array {
        $this->flushPdoParams();
        return $this->model_extension_oneclick_installer_module_installer->getInstalledExtensions();
    }

    private function jsonResponse(array $data): void {
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($data));
    }
}
