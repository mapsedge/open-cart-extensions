<?php
namespace Opencart\Admin\Controller\Extension\OneclickInstaller\Module;

/**
 * OneClick Extension Manager - Module Controller
 *
 * Namespace follows OC4 convention for extensions:
 * Opencart\Admin\Controller\Extension\{ExtensionFolder}\{Type}
 *
 * install() is called by Extensions > Extensions > Modules > Install
 * uninstall() is called by Extensions > Extensions > Modules > Uninstall
 */
class Installer extends \Opencart\System\Engine\Controller {

    public function install(): void {
        $this->load->model('setting/event');

        $events = [
            [
                'code'        => 'oneclick_menu',
                'description' => 'OneClick: suppress legacy Installer / Extensions / Modifications menu items',
                'trigger'     => 'admin/view/common/column_left/before',
                'action'      => 'extension/oneclick_installer/event/menu.suppress',
                'status'      => 1,
                'sort_order'  => 1,
            ],
            [
                'code'        => 'oneclick_redirect_installer',
                'description' => 'OneClick: redirect marketplace/installer to unified manager',
                'trigger'     => 'admin/controller/marketplace/installer/before',
                'action'      => 'extension/oneclick_installer/event/redirect.installer',
                'status'      => 1,
                'sort_order'  => 1,
            ],
            [
                'code'        => 'oneclick_redirect_modification',
                'description' => 'OneClick: redirect marketplace/modification to unified manager',
                'trigger'     => 'admin/controller/marketplace/modification/before',
                'action'      => 'extension/oneclick_installer/event/redirect.modification',
                'status'      => 1,
                'sort_order'  => 1,
            ],
            [
                'code'        => 'oneclick_redirect_extension',
                'description' => 'OneClick: redirect marketplace/extension to unified manager',
                'trigger'     => 'admin/controller/marketplace/extension/before',
                'action'      => 'extension/oneclick_installer/event/redirect.extension',
                'status'      => 1,
                'sort_order'  => 1,
            ],
        ];

        foreach ($events as $event) {
            $this->model_setting_event->deleteEventByCode($event['code']);
            $this->model_setting_event->addEvent($event);
        }
    }

    public function uninstall(): void {
        $this->load->model('setting/event');

        foreach ([
            'oneclick_menu',
            'oneclick_redirect_installer',
            'oneclick_redirect_modification',
            'oneclick_redirect_extension',
        ] as $code) {
            $this->model_setting_event->deleteEventByCode($code);
        }
    }

    public function index(): void {
        // Redirect straight to the manager page
        $this->response->redirect(
            $this->url->link('extension/oneclick_installer/module/manager', 'user_token=' . $this->session->data['user_token'])
        );
    }
}
