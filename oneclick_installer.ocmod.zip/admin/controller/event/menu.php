<?php
namespace Opencart\Admin\Controller\Extension\OneclickInstaller\Event;

/**
 * OneClick: Menu event handler
 *
 * Trigger: admin/view/common/column_left/before
 * - Suppresses legacy Installer / Extensions / Modifications menu items
 * - Injects OneClick Extension Manager link into the Extensions menu
 */
class Menu extends \Opencart\System\Engine\Controller {

    public function suppress(string &$route, array &$data): void {
        $suppress = [
            'marketplace/installer',
            'marketplace/modification',
            'marketplace/extension',
        ];

        if (empty($data['menus'])) return;

        // Inject OneClick Manager into the Extensions (menu-extension) section
        foreach ($data['menus'] as &$menu) {
            if (($menu['id'] ?? '') === 'menu-extension') {
                // Prepend our manager link as the first child
                array_unshift($menu['children'], [
                    'name'     => 'Extension Manager',
                    'href'     => $this->url->link(
                        'extension/oneclick_installer/module/manager',
                        'user_token=' . $this->session->data['user_token']
                    ),
                    'children' => [],
                ]);
                break;
            }
        }
        unset($menu);

        // Suppress the legacy items
        $data['menus'] = $this->filterMenuItems($data['menus'], $suppress);
    }

    private function filterMenuItems(array $items, array $suppress): array {
        $filtered = [];

        foreach ($items as $item) {
            $match = false;

            if (!empty($item['href'])) {
                foreach ($suppress as $route) {
                    if (strpos($item['href'], $route) !== false) {
                        $match = true;
                        break;
                    }
                }
            }

            if (!$match) {
                if (!empty($item['children'])) {
                    $item['children'] = $this->filterMenuItems($item['children'], $suppress);
                }
                $filtered[] = $item;
            }
        }

        return $filtered;
    }
}
