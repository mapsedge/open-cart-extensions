<?php
namespace Opencart\Admin\Controller\Extension\OneclickInstaller\Event;

/**
 * OneClick: Route redirect event handlers
 *
 * Actions:
 *   extension/oneclick_installer/event/redirect.installer
 *   extension/oneclick_installer/event/redirect.modification
 *   extension/oneclick_installer/event/redirect.extension
 */
class Redirect extends \Opencart\System\Engine\Controller {

    public function installer(string &$route, array &$data): void {
        $route = 'extension/oneclick_installer/module/manager';
    }

    public function modification(string &$route, array &$data): void {
        $route = 'extension/oneclick_installer/module/manager';
    }

    public function extension(string &$route, array &$data): void {
        $route = 'extension/oneclick_installer/module/manager';
    }
}
