document.addEventListener('DOMContentLoaded', function () {
  const header     = document.getElementById('header');
  const pageHeader = document.querySelector('.page-header');
  const colLeft    = document.getElementById('column-left');
  const content    = document.getElementById('content');

  function applyOffsets() {
    let topOffset = 0;

    if (header) {
      header.style.position = 'fixed';
      header.style.top      = '0';
      header.style.left     = '0';
      header.style.right    = '0';
      header.style.zIndex   = '1030';
      topOffset += header.offsetHeight;
    }

    if (pageHeader) {
      pageHeader.style.position   = 'fixed';
      pageHeader.style.top        = '48px';
      pageHeader.style.left       = '0';
      pageHeader.style.right      = '0';
      pageHeader.style.background = 'white';
      pageHeader.style.boxShadow  = '0 0 12px rgba(0,0,0,.5)';
      pageHeader.style.zIndex     = '1029';
      topOffset += pageHeader.offsetHeight;
    }

    document.body.style.paddingTop = topOffset + 'px';

    if (colLeft) {
      const sidebarWidth = colLeft.offsetWidth;
      colLeft.style.position  = 'fixed';
      colLeft.style.top       = '125px';
      colLeft.style.left      = '0';
      colLeft.style.bottom    = '0';
      colLeft.style.width     = sidebarWidth + 'px';
      colLeft.style.overflowY = 'auto';
      colLeft.style.zIndex    = '1028';

      if (content) {
        content.style.marginLeft = sidebarWidth + 'px';
        content.style.marginTop  = '1rem';
      }
    }
  }

  applyOffsets();
  window.addEventListener('resize', applyOffsets);
});
