<?php
/**
 * Language File - English (Admin)
 */

// Heading
$_['heading_title']    = 'Shippo Shipping';

// Text
$_['text_shipping']    = 'Shipping';
$_['text_success']     = 'Success: You have modified Shippo shipping!';
$_['text_edit']        = 'Edit Shippo Shipping';
$_['text_enabled']     = 'Enabled';
$_['text_disabled']    = 'Disabled';
$_['text_all_zones']   = 'All Zones';

// Entry
$_['entry_api_key']        = 'API Key';
$_['entry_test_mode']      = 'Test Mode';
$_['entry_origin_name']    = 'Origin Name';
$_['entry_origin_street']  = 'Origin Street';
$_['entry_origin_city']    = 'Origin City';
$_['entry_origin_state']   = 'Origin State';
$_['entry_origin_zip']     = 'Origin ZIP Code';
$_['entry_origin_country'] = 'Origin Country';
$_['entry_tax_class']      = 'Tax Class';
$_['entry_geo_zone']       = 'Geo Zone';
$_['entry_status']         = 'Status';
$_['entry_sort_order']     = 'Sort Order';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Shippo shipping!';
$_['error_api_key']    = 'API Key Required!';
