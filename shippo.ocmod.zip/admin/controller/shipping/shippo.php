<?php
namespace Opencart\Admin\Controller\Extension\Opencart\Shipping;
/**
 * Shippo Shipping Extension for OpenCart 4.x
 * 
 * @author Your Name
 * @version 1.0.0
 * @link https://goshippo.com/docs/
 */

class Shippo extends \Opencart\System\Engine\Controller {
    
    private $error = array();
    
    /**
     * Main installation/configuration page
     */
    public function index() {
        $this->load->language('extension/shipping/shippo');
        $this->document->setTitle($this->language->get('heading_title'));
        $this->load->model('setting/setting');
        
        // Handle form submission
        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            $this->model_setting_setting->editSetting('shipping_shippo', $this->request->post);
            $this->session->data['success'] = $this->language->get('text_success');
            $this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=shipping', true));
        }
        
        // Set up data for view
        $data['heading_title'] = $this->language->get('heading_title');
        $data['text_edit'] = $this->language->get('text_edit');
        $data['text_enabled'] = $this->language->get('text_enabled');
        $data['text_disabled'] = $this->language->get('text_disabled');
        $data['text_all_zones'] = $this->language->get('text_all_zones');
        
        $data['entry_api_key'] = $this->language->get('entry_api_key');
        $data['entry_test_mode'] = $this->language->get('entry_test_mode');
        $data['entry_origin_name'] = $this->language->get('entry_origin_name');
        $data['entry_origin_street'] = $this->language->get('entry_origin_street');
        $data['entry_origin_city'] = $this->language->get('entry_origin_city');
        $data['entry_origin_state'] = $this->language->get('entry_origin_state');
        $data['entry_origin_zip'] = $this->language->get('entry_origin_zip');
        $data['entry_origin_country'] = $this->language->get('entry_origin_country');
        $data['entry_tax_class'] = $this->language->get('entry_tax_class');
        $data['entry_geo_zone'] = $this->language->get('entry_geo_zone');
        $data['entry_status'] = $this->language->get('entry_status');
        $data['entry_sort_order'] = $this->language->get('entry_sort_order');
        
        $data['button_save'] = $this->language->get('button_save');
        $data['button_cancel'] = $this->language->get('button_cancel');
        
        // Error messages
        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }
        
        if (isset($this->error['api_key'])) {
            $data['error_api_key'] = $this->error['api_key'];
        } else {
            $data['error_api_key'] = '';
        }
        
        // Breadcrumbs
        $data['breadcrumbs'] = array();
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        );
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=shipping', true)
        );
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/opencart/shipping/shippo', 'user_token=' . $this->session->data['user_token'], true)
        );
        
        // Action URLs
        $data['action'] = $this->url->link('extension/opencart/shipping/shippo', 'user_token=' . $this->session->data['user_token'], true);
        $data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=shipping', true);
        
        // Get configuration values
        $data['shipping_shippo_api_key'] = $this->config->get('shipping_shippo_api_key') ?? '';
        $data['shipping_shippo_test_mode'] = $this->config->get('shipping_shippo_test_mode') ?? 1;
        $data['shipping_shippo_origin_name'] = $this->config->get('shipping_shippo_origin_name') ?? '';
        $data['shipping_shippo_origin_street'] = $this->config->get('shipping_shippo_origin_street') ?? '';
        $data['shipping_shippo_origin_city'] = $this->config->get('shipping_shippo_origin_city') ?? '';
        $data['shipping_shippo_origin_state'] = $this->config->get('shipping_shippo_origin_state') ?? '';
        $data['shipping_shippo_origin_zip'] = $this->config->get('shipping_shippo_origin_zip') ?? '';
        $data['shipping_shippo_origin_country'] = $this->config->get('shipping_shippo_origin_country') ?? 'US';
        $data['shipping_shippo_tax_class_id'] = $this->config->get('shipping_shippo_tax_class_id') ?? 0;
        $data['shipping_shippo_geo_zone_id'] = $this->config->get('shipping_shippo_geo_zone_id') ?? 0;
        $data['shipping_shippo_status'] = $this->config->get('shipping_shippo_status') ?? 0;
        $data['shipping_shippo_sort_order'] = $this->config->get('shipping_shippo_sort_order') ?? 0;
        
        // Load models for dropdowns
        $this->load->model('localisation/tax_class');
        $data['tax_classes'] = $this->model_localisation_tax_class->getTaxClasses();
        
        $this->load->model('localisation/geo_zone');
        $data['geo_zones'] = $this->model_localisation_geo_zone->getGeoZones();
        
        $this->load->model('localisation/country');
        $data['countries'] = $this->model_localisation_country->getCountries();
        
        // Render view
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        
        $this->response->setOutput($this->load->view('extension/shipping/shippo', $data));
    }
    
    /**
     * Validate form input
     */
    protected function validate() {
        if (!$this->user->hasPermission('modify', 'extension/opencart/shipping/shippo')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }
        
        if (!$this->request->post['shipping_shippo_api_key']) {
            $this->error['api_key'] = $this->language->get('error_api_key');
        }
        
        return !$this->error;
    }
    
    /**
     * Install the extension
     */
    public function install() {
        // Create custom tables if needed
        $this->db->query("
            CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "shippo_shipment` (
                `shipment_id` int(11) NOT NULL AUTO_INCREMENT,
                `order_id` int(11) NOT NULL,
                `shippo_transaction_id` varchar(255) NOT NULL,
                `tracking_number` varchar(255) DEFAULT NULL,
                `label_url` text,
                `carrier` varchar(100) DEFAULT NULL,
                `service` varchar(100) DEFAULT NULL,
                `cost` decimal(15,4) DEFAULT NULL,
                `date_created` datetime NOT NULL,
                PRIMARY KEY (`shipment_id`),
                KEY `order_id` (`order_id`)
            ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
        ");
    }
    
    /**
     * Uninstall the extension
     */
    public function uninstall() {
        // Optionally drop tables
        // $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "shippo_shipment`");
    }
}
