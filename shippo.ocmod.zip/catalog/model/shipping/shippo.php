<?php
namespace Opencart\Catalog\Model\Extension\Opencart\Shipping;
/**
 * Shippo Shipping Quote Module (Catalog/Frontend) for OpenCart 4.x
 * Provides real-time shipping rates to customers at checkout
 */

class Shippo extends \Opencart\System\Engine\Model {
    
    /**
     * Get shipping quotes from Shippo API
     * 
     * @param array $address Customer's shipping address
     * @return array Shipping method quotes
     */
    public function getQuote($address) {
        $this->load->language('extension/shipping/shippo');
        
        // Check if module is enabled
        $status = $this->config->get('shipping_shippo_status');
        if (!$status) {
            return array();
        }
        
        // Check geo zone
        $query = $this->db->query("
            SELECT * FROM " . DB_PREFIX . "zone_to_geo_zone 
            WHERE geo_zone_id = '" . (int)$this->config->get('shipping_shippo_geo_zone_id') . "' 
            AND country_id = '" . (int)$address['country_id'] . "' 
            AND (zone_id = '" . (int)$address['zone_id'] . "' OR zone_id = '0')
        ");
        
        if (!$this->config->get('shipping_shippo_geo_zone_id')) {
            $status = true;
        } elseif ($query->num_rows) {
            $status = true;
        } else {
            $status = false;
        }
        
        $method_data = array();
        
        if ($status) {
            // Prepare shipment data
            $shipment_data = $this->prepareShipmentData($address);
            
            // Get rates from Shippo API
            $rates = $this->getShippingRates($shipment_data);
            
            if ($rates) {
                $quote_data = array();
                
                foreach ($rates as $rate) {
                    $quote_data[$rate['object_id']] = array(
                        'code' => 'shippo.' . $rate['object_id'],
                        'title' => $rate['provider'] . ' - ' . $rate['servicelevel']['name'],
                        'cost' => (float)$rate['amount'],
                        'tax_class_id' => $this->config->get('shipping_shippo_tax_class_id'),
                        'text' => $this->currency->format($this->tax->calculate($rate['amount'], $this->config->get('shipping_shippo_tax_class_id'), $this->config->get('config_tax')), $this->session->data['currency'])
                    );
                }
                
                $method_data = array(
                    'code' => 'shippo',
                    'title' => $this->language->get('text_title'),
                    'quote' => $quote_data,
                    'sort_order' => $this->config->get('shipping_shippo_sort_order'),
                    'error' => false
                );
            }
        }
        
        return $method_data;
    }
    
    /**
     * Prepare shipment data for Shippo API
     */
    private function prepareShipmentData($address) {
        $this->load->model('catalog/product');
        
        // Get cart products
        $products = $this->cart->getProducts();
        
        // Calculate total weight (convert to ounces if needed)
        $total_weight = 0;
        $total_length = 0;
        $total_width = 0;
        $total_height = 0;
        
        foreach ($products as $product) {
            $product_info = $this->model_catalog_product->getProduct($product['product_id']);
            
            if ($product_info) {
                // Get weight in ounces
                $weight = $this->weight->convert($product_info['weight'], $product_info['weight_class_id'], $this->config->get('config_weight_class_id'));
                $total_weight += ($weight * $product['quantity']);
                
                // Get dimensions in inches
                $length = $this->length->convert($product_info['length'], $product_info['length_class_id'], $this->config->get('config_length_class_id'));
                $width = $this->length->convert($product_info['width'], $product_info['length_class_id'], $this->config->get('config_length_class_id'));
                $height = $this->length->convert($product_info['height'], $product_info['length_class_id'], $this->config->get('config_length_class_id'));
                
                $total_length = max($total_length, $length);
                $total_width = max($total_width, $width);
                $total_height += ($height * $product['quantity']);
            }
        }
        
        // Default package dimensions if not set
        if (!$total_length) $total_length = 12;
        if (!$total_width) $total_width = 12;
        if (!$total_height) $total_height = 6;
        if (!$total_weight) $total_weight = 16; // 1 lb
        
        return array(
            'address_from' => array(
                'name' => $this->config->get('shipping_shippo_origin_name'),
                'street1' => $this->config->get('shipping_shippo_origin_street'),
                'city' => $this->config->get('shipping_shippo_origin_city'),
                'state' => $this->config->get('shipping_shippo_origin_state'),
                'zip' => $this->config->get('shipping_shippo_origin_zip'),
                'country' => $this->config->get('shipping_shippo_origin_country')
            ),
            'address_to' => array(
                'name' => $address['firstname'] . ' ' . $address['lastname'],
                'street1' => $address['address_1'],
                'street2' => $address['address_2'] ?? '',
                'city' => $address['city'],
                'state' => $address['zone_code'] ?? $address['zone'],
                'zip' => $address['postcode'],
                'country' => $address['iso_code_2']
            ),
            'parcels' => array(
                array(
                    'length' => (string)$total_length,
                    'width' => (string)$total_width,
                    'height' => (string)$total_height,
                    'distance_unit' => 'in',
                    'weight' => (string)$total_weight,
                    'mass_unit' => 'oz'
                )
            )
        );
    }
    
    /**
     * Call Shippo API to get shipping rates
     */
    private function getShippingRates($shipment_data) {
        $api_key = $this->config->get('shipping_shippo_api_key');
        
        if (!$api_key) {
            return false;
        }
        
        $url = 'https://api.goshippo.com/shipments/';
        
        // Add async parameter to get rates immediately
        $shipment_data['async'] = false;
        
        $curl = curl_init();
        
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode($shipment_data),
            CURLOPT_HTTPHEADER => array(
                'Authorization: ShippoToken ' . $api_key,
                'Content-Type: application/json'
            ),
        ));
        
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        
        if ($err) {
            $this->log->write('SHIPPO ERROR: ' . $err);
            return false;
        }
        
        $result = json_decode($response, true);
        
        if (isset($result['rates']) && is_array($result['rates'])) {
            // Filter out rates with errors
            $valid_rates = array();
            foreach ($result['rates'] as $rate) {
                if (!isset($rate['messages']) || empty($rate['messages'])) {
                    $valid_rates[] = $rate;
                }
            }
            return $valid_rates;
        }
        
        if (isset($result['messages'])) {
            $this->log->write('SHIPPO API ERROR: ' . json_encode($result['messages']));
        }
        
        return false;
    }
}
