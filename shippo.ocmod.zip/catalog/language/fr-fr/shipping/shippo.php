<?php
$_['text_title']       = 'Livraison Shippo';
$_['text_weight']      = 'Poids :';
$_['text_description'] = 'Tarifs de livraison en temps réel';
