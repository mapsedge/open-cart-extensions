<?php
$_['text_title']       = 'Envío Shippo';
$_['text_weight']      = 'Peso:';
$_['text_description'] = 'Tarifas de envío en tiempo real';
