<?php
$_['text_title']       = 'Shippo Versand';
$_['text_weight']      = 'Gewicht:';
$_['text_description'] = 'Echtzeit-Versandtarife';
