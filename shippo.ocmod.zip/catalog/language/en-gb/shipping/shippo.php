<?php
/**
 * Language File - English (Catalog/Frontend)
 */

// Text
$_['text_title']       = 'Shippo Shipping';
$_['text_weight']      = 'Weight:';
$_['text_description'] = 'Real-time shipping rates';
